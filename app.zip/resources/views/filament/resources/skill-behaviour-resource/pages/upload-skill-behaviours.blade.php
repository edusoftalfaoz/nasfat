<x-filament::page>
    <form wire:submit.prevent="upload" class="space-y-6">
        {{ $this->form }}
        <x-filament::button type="submit">
            Upload
        </x-filament::button>
    </form>
</x-filament::page>
